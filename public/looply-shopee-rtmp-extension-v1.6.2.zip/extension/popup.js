'use strict';
const API = 'http://127.0.0.1:8790';
const $ = id => document.getElementById(id);
const controls = {
  video:$('video'), serverUrl:$('serverUrl'), streamKey:$('streamKey'),
  resolution:$('resolution'), bitrate:$('bitrate'), start:$('start'),
  stop:$('stop'), stopLive:$('stopLive')
};
let lastRunning = null;
let remoteStopAt = null;
let streamRunning = false;
let uploadInProgress = false;

function message(text, error = false) {
  $('message').textContent = text || '';
  $('message').style.color = error ? '#ff8b5c' : 'var(--muted)';
}

function switchView(view) {
  const live = view === 'live';
  $('liveView').hidden = !live;
  $('setupView').hidden = live;
  $('tabLive').classList.toggle('active', live);
  $('tabSetup').classList.toggle('active', !live);
}

function formatDuration(milliseconds) {
  const seconds = Math.max(0, Math.floor(milliseconds / 1000));
  const h = String(Math.floor(seconds / 3600)).padStart(2, '0');
  const m = String(Math.floor((seconds % 3600) / 60)).padStart(2, '0');
  const s = String(seconds % 60).padStart(2, '0');
  return `${h}:${m}:${s}`;
}

function syncLiveSummary() {
  const selectedMs = Math.max(1, Number($('timerMinutes').value) || 60) * 60 * 1000;
  const remainingMs = remoteStopAt ? Math.max(0, remoteStopAt - Date.now()) : selectedMs;
  $('liveElapsed').textContent = formatDuration(remainingMs);
  $('timerSchedule').disabled = !streamRunning;
  $('timerCancel').disabled = !streamRunning || !remoteStopAt;
  $('timerSchedule').classList.toggle('timer-active', Boolean(remoteStopAt));
  $('timerHint').textContent = remoteStopAt
    ? `Encerramento automático programado para ${new Date(remoteStopAt).toLocaleTimeString('pt-BR', { hour:'2-digit', minute:'2-digit' })}.`
    : 'A contagem começa junto com a transmissão.';
  $('liveFormat').textContent = controls.resolution.options[controls.resolution.selectedIndex]?.text || '—';
  $('liveBitrate').textContent = controls.bitrate.options[controls.bitrate.selectedIndex]?.text || '—';
}

async function scheduleStop(minutes) {
  try {
    const data = await request('/schedule-stop', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ minutes }) });
    remoteStopAt = data.stopAt || null;
    await chrome.storage.local.set({ timerMinutes:$('timerMinutes').value });
    syncLiveSummary();
  } catch (error) { message(error.message, true); }
}

async function request(route, options) {
  const response = await fetch(API + route, options);
  const data = await response.json().catch(() => ({}));
  if (!response.ok || data.ok === false) throw new Error(data.message || 'Falha na ponte local.');
  return data;
}

async function uploadVideo(file) {
  uploadInProgress = true;
  controls.start.disabled = true;
  $('uploadProgress').classList.add('uploading');
  $('uploadProgress').textContent = `Preparando ${file.name}…`;
  try {
    const data = await new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', API + '/upload');
      xhr.timeout = 30 * 60 * 1000;
      xhr.setRequestHeader('Content-Type', 'application/octet-stream');
      xhr.setRequestHeader('X-File-Name', encodeURIComponent(file.name));
      xhr.upload.onprogress = event => {
        const percent = event.lengthComputable ? Math.min(99, Math.round((event.loaded / event.total) * 100)) : null;
        const sent = (event.loaded / 1024 / 1024).toFixed(1);
        const total = event.lengthComputable ? ` de ${(event.total / 1024 / 1024).toFixed(1)} MB` : ' MB';
        $('uploadProgress').textContent = percent === null ? `Enviando ${sent}${total}…` : `Enviando ${percent}% — ${sent}${total}`;
      };
      xhr.onload = () => {
        let response = {};
        try { response = JSON.parse(xhr.responseText || '{}'); } catch {}
        if (xhr.status >= 200 && xhr.status < 300 && response.ok !== false) resolve(response);
        else reject(new Error(response.message || `Falha no envio (HTTP ${xhr.status}).`));
      };
      xhr.onerror = () => reject(new Error('A ponte local desconectou durante o envio. Reinicie iniciar-ponte.bat e tente novamente.'));
      xhr.ontimeout = () => reject(new Error('O envio demorou demais e foi cancelado. Tente novamente.'));
      xhr.onabort = () => reject(new Error('O envio foi cancelado.'));
      xhr.send(file);
    });
    $('uploadProgress').textContent = `✓ ${data.fileName} pronto para transmitir.`;
  } finally {
    uploadInProgress = false;
    $('uploadProgress').classList.remove('uploading');
  }
}

async function refresh() {
  try {
    const health = await request('/health');
    const status = await request('/status');
    const bridgeText = health.ffmpeg ? status.message : 'Ponte aberta, mas o FFmpeg não foi encontrado.';
    $('bridge').className = health.ffmpeg ? 'status ok' : 'status error';
    $('bridge').textContent = bridgeText;
    $('liveStateText').textContent = bridgeText;
    streamRunning = Boolean(status.running);
    remoteStopAt = status.stopAt || null;
    controls.start.disabled = uploadInProgress || !health.ffmpeg || status.running;
    controls.stop.disabled = !status.running;
    controls.stopLive.disabled = !status.running;
    if (status.lastError) message(status.lastError, true);
    if (status.running && lastRunning !== true) switchView('live');
    lastRunning = status.running;
    syncLiveSummary();
  } catch {
    streamRunning = false;
    remoteStopAt = null;
    $('bridge').className = 'status error';
    $('bridge').textContent = 'Ponte local desligada. Execute iniciar-ponte.bat.';
    $('liveStateText').textContent = 'Ponte local desconectada';
    controls.start.disabled = true;
    controls.stop.disabled = true;
    controls.stopLive.disabled = true;
  }
}

async function stopTransmission() {
  try {
    await request('/stop', { method:'POST' });
    message('Transmissão interrompida.');
    switchView('live');
  } catch (error) { message(error.message, true); }
  refresh();
}

$('tabLive').addEventListener('click', () => switchView('live'));
$('tabSetup').addEventListener('click', () => switchView('setup'));
$('privacyToggle').addEventListener('click', () => switchView('live'));
controls.resolution.addEventListener('change', syncLiveSummary);
controls.bitrate.addEventListener('change', syncLiveSummary);
$('timerMinutes').addEventListener('input', () => {
  const value = Math.min(720, Math.max(1, Number($('timerMinutes').value) || 60));
  chrome.storage.local.set({ timerMinutes:value });
  if (!remoteStopAt) syncLiveSummary();
});
$('timerSchedule').addEventListener('click', () => scheduleStop(Math.min(720, Math.max(1, Number($('timerMinutes').value) || 60))));
$('timerCancel').addEventListener('click', () => scheduleStop(0));

controls.video.addEventListener('change', async () => {
  const file = controls.video.files[0];
  if (!file) return;
  try { await uploadVideo(file); message('Vídeo carregado.'); } catch (error) { message(error.message, true); }
  refresh();
});

controls.start.addEventListener('click', async () => {
  try {
    const serverUrl = controls.serverUrl.value.trim();
    const streamKey = controls.streamKey.value.trim();
    if (!serverUrl || !streamKey) throw new Error('Informe a URL e a chave da transmissão.');
    const durationMinutes = Math.min(720, Math.max(1, Number($('timerMinutes').value) || 60));
    const started = await request('/start', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ serverUrl, streamKey, resolution:controls.resolution.value, bitrate:controls.bitrate.value, durationMinutes }) });
    remoteStopAt = started.stopAt || null;
    await chrome.storage.local.set({ serverUrl, resolution:controls.resolution.value, bitrate:controls.bitrate.value, timerMinutes:durationMinutes });
    controls.streamKey.value = '';
    message('Comando enviado. Confira a prévia na plataforma antes de entrar ao vivo.');
    switchView('live');
    syncLiveSummary();
  } catch (error) { message(error.message, true); }
  refresh();
});

controls.stop.addEventListener('click', stopTransmission);
controls.stopLive.addEventListener('click', stopTransmission);

(async () => {
  const saved = await chrome.storage.local.get(['serverUrl','resolution','bitrate','timerMinutes']);
  if (saved.serverUrl) controls.serverUrl.value = saved.serverUrl;
  if (saved.resolution) controls.resolution.value = saved.resolution;
  if (saved.bitrate) controls.bitrate.value = saved.bitrate;
  if (saved.timerMinutes) $('timerMinutes').value = saved.timerMinutes;
  switchView('live');
  syncLiveSummary();
  await refresh();
  setInterval(syncLiveSummary, 1000);
  setInterval(refresh, 1500);
})();
