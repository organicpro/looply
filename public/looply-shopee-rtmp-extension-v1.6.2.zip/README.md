# Looply Shopee RTMP

Projeto independente da extensão Looply principal. Ele transmite um vídeo local em loop para uma URL RTMP/RTMPS usando uma extensão do Chrome e uma ponte local em Node.js + FFmpeg.

## Uso

1. Instale o FFmpeg e confirme que `ffmpeg -version` funciona no PowerShell.
2. Execute `iniciar-ponte.bat`.
3. No Chrome, abra `chrome://extensions`, ative o modo do desenvolvedor e carregue a pasta `extension` sem compactação.
4. Abra a extensão, selecione o vídeo, informe URL e chave da live e clique em **Iniciar transmissão**.
5. Mantenha a janela da ponte aberta enquanto estiver ao vivo.

Nunca compartilhe a chave da transmissão. A chave é enviada somente para a ponte local e não é gravada pela extensão.

