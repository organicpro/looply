'use strict';

const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn, spawnSync } = require('child_process');
const { pipeline } = require('stream/promises');

const HOST = '127.0.0.1';
const PORT = 8790;
const MAX_UPLOAD_BYTES = 20 * 1024 * 1024 * 1024;
const uploadDir = path.join(os.tmpdir(), 'looply-shopee-rtmp');
fs.mkdirSync(uploadDir, { recursive: true });

function findFfmpeg() {
  if (process.env.LOOPLY_FFMPEG && fs.existsSync(process.env.LOOPLY_FFMPEG)) return process.env.LOOPLY_FFMPEG;
  const direct = spawnSync('ffmpeg', ['-version'], { windowsHide: true, encoding: 'utf8' });
  if (direct.status === 0) return 'ffmpeg';
  if (process.platform === 'win32' && process.env.LOCALAPPDATA) {
    const packages = path.join(process.env.LOCALAPPDATA, 'Microsoft', 'WinGet', 'Packages');
    if (fs.existsSync(packages)) {
      for (const packageName of fs.readdirSync(packages)) {
        if (!packageName.startsWith('Gyan.FFmpeg_')) continue;
        const packageDir = path.join(packages, packageName);
        for (const buildName of fs.readdirSync(packageDir)) {
          const candidate = path.join(packageDir, buildName, 'bin', 'ffmpeg.exe');
          if (fs.existsSync(candidate)) return candidate;
        }
      }
    }
  }
  return null;
}

const FFMPEG_PATH = findFfmpeg();

let uploadedFile = null;
let ffmpegProcess = null;
let autoStopTimer = null;
let stopReason = null;
let state = { running: false, message: 'Ponte pronta.', startedAt: null, stopAt: null, lastError: null };

function corsHeaders(req) {
  const origin = req.headers.origin || '';
  const allowed = origin.startsWith('chrome-extension://') || origin === `http://${HOST}:${PORT}`;
  return {
    'Access-Control-Allow-Origin': allowed ? origin : 'null',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, X-File-Name',
    'Cache-Control': 'no-store',
  };
}

function sendJson(req, res, status, body) {
  res.writeHead(status, { ...corsHeaders(req), 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(body));
}

function readJson(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.setEncoding('utf8');
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 1024 * 1024) req.destroy(new Error('Requisição muito grande.'));
    });
    req.on('end', () => {
      try { resolve(JSON.parse(body || '{}')); } catch { reject(new Error('JSON inválido.')); }
    });
    req.on('error', reject);
  });
}

function clearAutoStop() {
  if (autoStopTimer) clearTimeout(autoStopTimer);
  autoStopTimer = null;
  state.stopAt = null;
}

function stopStream(reason = 'Transmissão interrompida.') {
  if (!ffmpegProcess) return false;
  clearAutoStop();
  stopReason = reason;
  const processToStop = ffmpegProcess;
  ffmpegProcess = null;
  processToStop.kill('SIGTERM');
  setTimeout(() => {
    if (!processToStop.killed) processToStop.kill('SIGKILL');
  }, 3000).unref();
  state = { running: false, message: reason, startedAt: null, stopAt: null, lastError: null };
  return true;
}

function scheduleAutoStop(minutes) {
  if (!ffmpegProcess) throw new Error('Inicie a transmissão antes de programar o encerramento.');
  clearAutoStop();
  const value = Number(minutes);
  if (value === 0) return null;
  if (!Number.isFinite(value) || value < 1 || value > 720) throw new Error('Defina um tempo entre 1 e 720 minutos.');
  state.stopAt = Date.now() + Math.round(value * 60 * 1000);
  autoStopTimer = setTimeout(() => stopStream('Live encerrada automaticamente no tempo definido.'), state.stopAt - Date.now());
  autoStopTimer.unref();
  return state.stopAt;
}

function buildOutputUrl(serverUrl, streamKey) {
  const cleanServer = String(serverUrl || '').trim();
  const cleanKey = String(streamKey || '').trim();
  if (!/^rtmps?:\/\//i.test(cleanServer)) throw new Error('A URL deve começar com rtmp:// ou rtmps://');
  if (!cleanKey) throw new Error('Informe a chave da transmissão.');
  return cleanServer.replace(/\/+$/, '') + '/' + cleanKey.replace(/^\/+/, '');
}

function startStream(options) {
  if (!uploadedFile || !fs.existsSync(uploadedFile)) throw new Error('Envie um vídeo primeiro.');
  if (ffmpegProcess) throw new Error('Já existe uma transmissão ativa.');

  const outputUrl = buildOutputUrl(options.serverUrl, options.streamKey);
  const bitrate = ['1500k', '2500k', '3500k', '4500k', '6000k'].includes(options.bitrate) ? options.bitrate : '3500k';
  const resolution = options.resolution === '720x1280' ? '720:1280' : '1280:720';
  const [width, height] = resolution.split(':');
  const videoFilter = `scale=${width}:${height}:force_original_aspect_ratio=decrease,pad=${width}:${height}:(ow-iw)/2:(oh-ih)/2,format=yuv420p`;
  const args = [
    '-hide_banner', '-loglevel', 'warning', '-progress', 'pipe:2', '-nostats', '-re', '-stream_loop', '-1', '-i', uploadedFile,
    '-map', '0:v:0', '-map', '0:a:0?',
    '-vf', videoFilter, '-r', '30', '-fps_mode', 'cfr', '-c:v', 'libx264', '-preset', 'veryfast',
    '-tune', 'zerolatency', '-profile:v', 'main',
    '-b:v', bitrate, '-maxrate', bitrate, '-bufsize', String(parseInt(bitrate, 10) * 2) + 'k',
    '-g', '30', '-keyint_min', '30', '-sc_threshold', '0',
    '-c:a', 'aac', '-b:a', '160k', '-ar', '48000', '-ac', '2',
    '-flvflags', 'no_duration_filesize', '-f', 'flv', outputUrl,
  ];

  if (!FFMPEG_PATH) throw new Error('FFmpeg não encontrado. Instale-o e reinicie a ponte.');
  ffmpegProcess = spawn(FFMPEG_PATH, args, { windowsHide: true, stdio: ['ignore', 'ignore', 'pipe'] });
  stopReason = null;
  state = { running: true, message: 'Conectando à plataforma…', startedAt: Date.now(), stopAt: null, lastError: null };
  scheduleAutoStop(options.durationMinutes || 60);
  let recentError = '';
  ffmpegProcess.stderr.on('data', chunk => {
    recentError = (recentError + chunk.toString()).slice(-3000);
    if (/progress=continue|progress=end|frame=\d+/i.test(recentError)) state.message = 'Transmitindo ao vivo.';
  });
  ffmpegProcess.on('error', error => {
    clearAutoStop();
    ffmpegProcess = null;
    state = { running: false, message: 'Falha ao iniciar o FFmpeg.', startedAt: null, stopAt: null, lastError: error.message };
  });
  ffmpegProcess.on('exit', code => {
    clearAutoStop();
    ffmpegProcess = null;
    const expectedMessage = stopReason;
    stopReason = null;
    const rejectedByServer = /-10053|connection reset|broken pipe/i.test(recentError);
    const friendlyError = rejectedByServer
      ? 'A Shopee encerrou a conexão RTMP. Gere uma nova URL e chave na sessão atual da live, cole novamente e tente com 2500 kbps. Não reutilize uma chave antiga nem deixe OBS conectado ao mesmo tempo.'
      : (recentError.trim() || null);
    state = {
      running: false,
      message: expectedMessage || `Transmissão encerrada (código ${code}).`,
      startedAt: null, stopAt: null,
      lastError: expectedMessage ? null : friendlyError,
    };
  });
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, corsHeaders(req));
    return res.end();
  }

  try {
    if (req.method === 'GET' && req.url === '/health') {
      return sendJson(req, res, 200, { ok: true, ffmpeg: Boolean(FFMPEG_PATH) });
    }
    if (req.method === 'GET' && req.url === '/status') {
      return sendJson(req, res, 200, { ...state, uploaded: Boolean(uploadedFile), fileName: uploadedFile ? path.basename(uploadedFile) : null });
    }
    if (req.method === 'POST' && req.url === '/upload') {
      if (ffmpegProcess) throw new Error('Pare a transmissão antes de trocar o vídeo.');
      const length = Number(req.headers['content-length'] || 0);
      if (length > MAX_UPLOAD_BYTES) throw new Error('Arquivo maior que 20 GB.');
      const safeName = path.basename(decodeURIComponent(req.headers['x-file-name'] || 'video.mp4')).replace(/[^a-zA-Z0-9._-]/g, '_');
      const target = path.join(uploadDir, `${Date.now()}-${safeName}`);
      const output = fs.createWriteStream(target, { flags: 'wx' });
      let received = 0;
      req.on('data', chunk => {
        received += chunk.length;
        if (received > MAX_UPLOAD_BYTES) req.destroy(new Error('Arquivo maior que 20 GB.'));
      });
      try {
        await pipeline(req, output);
      } catch (error) {
        if (fs.existsSync(target)) fs.unlinkSync(target);
        throw new Error(req.aborted ? 'O envio do vídeo foi interrompido. Tente novamente.' : error.message);
      }
      if (!received) {
        if (fs.existsSync(target)) fs.unlinkSync(target);
        throw new Error('O arquivo enviado está vazio.');
      }
      if (uploadedFile && fs.existsSync(uploadedFile)) fs.unlinkSync(uploadedFile);
      uploadedFile = target;
      state = { running: false, message: 'Vídeo recebido e pronto.', startedAt: null, stopAt: null, lastError: null };
      return sendJson(req, res, 200, { ok: true, fileName: safeName });
    }
    if (req.method === 'POST' && req.url === '/start') {
      const body = await readJson(req);
      startStream(body);
      return sendJson(req, res, 200, { ok: true, stopAt: state.stopAt });
    }
    if (req.method === 'POST' && req.url === '/schedule-stop') {
      const body = await readJson(req);
      const stopAt = scheduleAutoStop(body.minutes);
      return sendJson(req, res, 200, { ok: true, stopAt });
    }
    if (req.method === 'POST' && req.url === '/stop') {
      stopStream();
      return sendJson(req, res, 200, { ok: true });
    }
    return sendJson(req, res, 404, { ok: false, message: 'Rota não encontrada.' });
  } catch (error) {
    return sendJson(req, res, 400, { ok: false, message: error.message });
  }
});

server.listen(PORT, HOST, () => {
  console.log(`Looply Shopee RTMP disponível em http://${HOST}:${PORT}`);
  console.log('Mantenha esta janela aberta durante a transmissão.');
});

process.on('SIGINT', () => { stopStream(); server.close(() => process.exit(0)); });
