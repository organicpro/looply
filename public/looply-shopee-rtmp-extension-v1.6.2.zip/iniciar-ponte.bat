@echo off
cd /d "%~dp0bridge"
node server.js
pause

